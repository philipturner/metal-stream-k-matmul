
//===----------------------------------------------------------------------===//
// String-K Matrix Multiplications on the Apple GPU
//===----------------------------------------------------------------------===//

// Self-contained script and mini-research paper for String-K matmul [1].

// Author: Philip Turner
// Date: 4/10/23-4/11/23

//===----------------------------------------------------------------------===//
// Introduction
//===----------------------------------------------------------------------===//

// TODO: Write brief on background information

//===----------------------------------------------------------------------===//
// Methods
//===----------------------------------------------------------------------===//

import Metal
import MetalPerformanceShadersGraph
import AppleGPUInfo

// Using the Swift API for AppleGPUInfo, although I also made a C API for use
// with the Metal C++ bindings. I need to use Swift for this project to access
// Metal Performance Shaders.

// The GPU core count helps us determine the right amount of persistent
// threadgroups for the String-K algorithm. The Metal API does not provide this
// metric directly, hence the need for `AppleGPUInfo`.
let infoDevice = try GPUInfoDevice()
print("GPU cores:", infoDevice.coreCount)
print("GPU max TFLOPS:", rint(infoDevice.flops / 1e9) / 1e3)

// Objective: Benchmark square matrices across the entire range at granularity
// of 1, 1.5, 2, 3, 4, 6, 8, 12, 16, ... Then, benchmark non-square matmuls
// frequently encountered in machine learning. The latter will use large weight
// matrices, but batches of (32, 64, 128, 256, 512). To demonstrate how String-K
// generalizes to a variety of GEMM shapes, also test odd sizes like 40, 48, ...
// within the granularity of the block size.
let benchmarkTrials: Int = 10
let weightsMatrixSize: Int = 128
let batchSize: Int = 128
let algorithm: MatmulAlgorithm = .mps
let verifyingResults: Bool = false // only enable for very small matrices

// Additional hyperparameters (please don't change these).
typealias DataType = Float16
let mpsDataType: MPSDataType = .float16
let tileSizeM: Int = 32 // variable name sourced from [3]
let tileSizeK: Int = 16
let tileSizeN: Int = 32
let blockSizeM: Int = 4
let blockSizeN: Int = 4

// Initialize resources for accessing the Metal API. I will submit one command
// per Metal command buffer, which is not optimal usage of the API. However, it
// should not hinder the ability to benchmark this particular use case.
let devices: [MTLDevice] = MTLCopyAllDevices()
guard let device = devices.first(where: { $0.supportsFamily(.apple7) }) else {
  // Apple 7 includes all Apple silicon Macs and all iOS devices with A14+.
  fatalError("This script assumes you have the Apple 7 family.")
}
let commandQueue: MTLCommandQueue = device.makeCommandQueue()!

// Create buffers to hold the matrix data. These will be cycled through memory
// multiple times to fill the caches, maximizing performance. This technique
// provides the most consistent metrics and the most straightforward comparison
// of two different algorithms. However, it will overestimate real-world perf.
let weightsMatrixBytes: Int =
  weightsMatrixSize * weightsMatrixSize * MemoryLayout<DataType>.stride
let activationsMatrixBytes: Int =
  weightsMatrixSize * batchSize * MemoryLayout<DataType>.stride
let weightsMatrix: MTLBuffer = device.makeBuffer(
  length: weightsMatrixBytes, options: .storageModeShared)!
let inputsMatrix: MTLBuffer = device.makeBuffer(
  length: activationsMatrixBytes, options: .storageModeShared)!
let outputsMatrix: MTLBuffer = device.makeBuffer(
  length: activationsMatrixBytes, options: .storageModeShared)!

// The algorithms to test. You can choose between naive, String-K, and Metal
// Performance Shaders (MPS). For convenience, the choice of algorithm appears
// alongside the other hyperparameters above (trials, size, batch, etc.)
enum MatmulAlgorithm {
  case naive
  case stringK
  case mps
}
let dataTypeRepr = mpsDataType == .float32 ? "float" : "half"
let shaderSource: String = """
#include <metal_stdlib>
using namespace metal;

typedef \(dataTypeRepr) real;

struct Arguments {
  uint weightsSize; // M, K
  uint batchSize; // N
};

kernel void naiveMatmul(
  const device real* weights [[buffer(0)]],
  const device real* inputs [[buffer(1)]],
  device real* outputs [[buffer(2)]],
  constant Arguments& args [[buffer(3)]],
  uint2 tid [[thread_position_in_grid]]
) {
  uint outputsRowID = tid.y; // 0 to M
  uint outputsColumnID = tid.x; // 0 to N
  uint weightsRowID = outputsRowID; // 0 to M
  uint weightsRowOffset = weightsRowID * args.weightsSize; // * K
  uint inputsColumnID = outputsColumnID; // 0 to N

  real acc = 0;
  for (uint k = 0; k < args.weightsSize; ++k) {
    uint weightsIndex = weightsRowOffset + k;
    uint inputsIndex = k * args.batchSize + inputsColumnID;
    acc += weights[weightsIndex] * inputs[inputsIndex];
  }

  uint outputsIndex = outputsRowID * args.batchSize + outputsColumnID;
  outputs[outputsIndex] = acc;
}
"""
let library: MTLLibrary = try device.makeLibrary(
  source: shaderSource, options: nil)

// TODO: Verify that the results are correct, for a small-enough matrix.

//===----------------------------------------------------------------------===//
// Results
//===----------------------------------------------------------------------===//

// TODO: Put table here

// Print the table + the formatting, removing the need to do this manually.
print("===")

//===----------------------------------------------------------------------===//
// Discussion
//===----------------------------------------------------------------------===//

// TODO: Future steps

// Future steps: test several shapes, graph intensity vs ALU
// Future steps: aggregate performance data in a serialized file format for
//               benchmarking over several hours
// Future steps: support and benchmark odd matrix dimensions

//===----------------------------------------------------------------------===//
// References
//===----------------------------------------------------------------------===//

// [1] "Stream-K: Work-centric Parallel Decomposition for Dense Matrix-Matrix
//       Multiplication on the GPU", https://arxiv.org/abs/2301.03598
// [2] Open-source matmul algorithm for the Apple GPU using simdgroup matrix
//       multiply, https://github.com/geohot/tinygrad,
//       file: extra/gemm/metal_matmul.py,
//       commit: 68e45fca18d84d871a3fd97b66c26cbbabb77356
// [3] Open-source matmul and Winograd algorithm for generic OpenCL platforms,
//       https://github.com/artyom-beilis/dlprimitives/,
//       file: src/kernels/sgemm.cl,
//       commit: 7280aca1648becfd96991e10d095faac94f7b65e
// [4] "Apple GPU microarchitecture",
//       https://github.com/philipturner/metal-benchmarks,
//       commit: 45ebc9fda73c80f81ff8ecde9eb084f8fa1e4775
